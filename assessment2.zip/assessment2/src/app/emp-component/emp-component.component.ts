import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
@Component({
  selector: 'app-emp-component',
  templateUrl: './emp-component.component.html',
  styleUrls: ['./emp-component.component.scss']
})
export class EmpComponentComponent implements OnInit {
  isUpdate=false;
  selectedIndex :number;
  employeeslist:Employee[];
  constructor(private empservice:EmployeeService)
  { }
  ngOnInit(){
    this.employeeslist=this.empservice.showEmployees();

  }
  empEdit(i)
  {
    this.selectedIndex=i;
    this.isUpdate=true; 
  }
  empDelete(i)
  {
    this.empservice.emplist.splice(i,1);
  }
}

