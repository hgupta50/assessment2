import { Component, OnInit, Input } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {

  constructor(private employeeServive:EmployeeService) { }
  @Input() index: number;
  employee=new Employee();
  ngOnInit() {
    this.employee=this.employeeServive.emplist[this.index];
  }
  empUpdate()
  {
    this.employeeServive.emplist[this.index]=this.employee;
  }



}
