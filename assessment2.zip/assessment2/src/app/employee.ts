export class Employee{
    id:number;
    name:string;
    GroupName:string;
    ModifiedDate:Date;
}