import { Component, OnInit } from '@angular/core';
import { Employee} from '../employee';
import {EmployeeService} from '../employee.service';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
  constructor(private employeeService:EmployeeService) { }
   employee=new Employee ();
   ngOnInit() {}
   empSave()
   {
     this.employeeService.addEmployee(this.employee);
    console.log(this.employee);
  }
}
