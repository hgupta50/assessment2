import { Injectable } from '@angular/core';
import {Employee} from './employee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  emplist:Employee[]=[
    {id:1, name:"Engineering", GroupName:"Research and Development",ModifiedDate:new Date("2002-06-01")},
    {id:2, name:"Tool Design", GroupName:"Research and Development",ModifiedDate:new Date("2002-06-01")},
    {id:3, name:"Sales", GroupName:"Sales and Marketing",ModifiedDate:new Date("2002-06-01")},
    {id:4, name:"Marketing", GroupName:"Sales and Marketing",ModifiedDate:new Date("2002-06-01")},
    {id:5, name:"Purchasing", GroupName:"Inventory Management",ModifiedDate:new Date("2002-06-01")},
    {id:6, name:"Research and Development", GroupName:"Research and Development",ModifiedDate:new Date("2002-06-01")},
    {id:7, name:"Production", GroupName:"Manufacturing",ModifiedDate:new Date("2002-06-01")},
    {id:8, name:"Production Control", GroupName:"Manufacturing",ModifiedDate:new Date("2002-06-01")},
    {id:9, name:"Human Resources", GroupName:"Executive general and administration",ModifiedDate:new Date("2002-06-01")},
    {id:10, name:"Finance", GroupName:"Executive general and administration",ModifiedDate:new Date("2002-06-01")},
    {id:11, name:"Information Services", GroupName:"Executive general and administration",ModifiedDate:new Date("2002-06-01")},
    {id:12, name:"Document Control", GroupName:"Quality Assurance",ModifiedDate:new Date("2002-06-01")},
    {id:13, name:"quality Assurance", GroupName:"Quality Assurance",ModifiedDate:new Date("2002-06-01")},
    {id:14, name:"Facilities and Maintenance", GroupName:"Executive general and administration",ModifiedDate:new Date("2002-06-01")},
    {id:15, name:"Shipping and Receiving", GroupName:"Inventory Management",ModifiedDate:new Date("2002-06-01")},
    {id:16, name:"Executive", GroupName:"Executive general and administration",ModifiedDate:new Date("2002-06-01")},
    // {id:2, name:"Harsit", gender:"male", salary:9000,dob:new Date("1999-10-18")},
    // {id:3, name:"Rahul", gender:"male", salary:7000,dob:new Date("1998-04-19")},
    // {id:4, name:"Kaavya", gender:"female", salary:10000,dob:new Date("1995-10-13")},
  ];

  constructor() { }
  showEmployees(){
    return this.emplist;
  }
  addEmployee(employee:Employee){
    this.emplist.push(employee);
    console.log(this.emplist);
  }
}